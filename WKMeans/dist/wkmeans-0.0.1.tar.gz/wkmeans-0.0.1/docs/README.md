This repository is an attempt to emulate the w-Kmeans algorithm from the paper
Horvath, B., Issa, Z., Muguruza, A. (2021). Clustering Market Regimes using the Wasserstein Distance. arXiv preprint arXiv:2110.11848.

The class operates similarly to the sklearn api in its functionality
